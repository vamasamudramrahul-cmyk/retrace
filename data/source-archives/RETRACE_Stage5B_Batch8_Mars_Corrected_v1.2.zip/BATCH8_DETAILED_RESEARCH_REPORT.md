# RETRACE Stage 5B — Batch 8 Mars Detailed Research Report (Corrected v1.1)

**Status:** Corrected package prepared for independent Chat 25 re-audit; not accepted.

## Scope

Five permanent records only: MARS-EQ-0036 through MARS-EQ-0040. Names, destinations, and approved mission associations are preserved.

## Research and correction summary

- Added NASA 2026 Planetary Mission Senior Review source SRC-0167 for SuperCam, MEDA, and RIMFAX.
- SuperCam and RIMFAX are classified OPERATIONAL effective 2026-03-02 based on NASA’s dated assessment that they were among the remaining instruments acquiring data and generally healthy.
- MEDA is classified OPERATIONAL with an explicit degraded/partial-operation qualification: only one wind sensor continued to return data; the other wind sensors were no longer operational.
- SEIS status is null because lander communication loss and mission retirement do not prove instrument-specific final health.
- HP³ package status is null. The mole effort ended 2021-01-09, but that does not prove the complete package was removed or that every component was inactive.
- Corrected Mars 2020 launch/landing event claim-source links to the dedicated mission-event claims and SRC-0154.
- Corrected SEIS and HP³ timeline events to use event-specific claims and sources, including separate mission retirement and last-contact claims.
- Mars 2020 records use approved mission ID MIS-0020. No approved InSight mission ID was present in the supplied master inventory; no ID was invented.

## Final counts (reconciled to equipment JSON) (reconciled to equipment JSON)

- Equipment records: 5
- Unique sources: 15
- Evidence claims: 38
- Timeline events: 19

## Equipment records

### MARS-EQ-0036 — Perseverance SuperCam
- Mission: Mars 2020
- Mission IDs: MIS-0020
- Equipment status: OPERATIONAL
- Sources: 4; claims: 6; timeline events: 2

### MARS-EQ-0037 — Perseverance Mars Environmental Dynamics Analyzer (MEDA)
- Mission: Mars 2020
- Mission IDs: MIS-0020
- Equipment status: OPERATIONAL
- Sources: 4; claims: 6; timeline events: 2

### MARS-EQ-0038 — Perseverance Radar Imager for Mars' Subsurface Experiment (RIMFAX)
- Mission: Mars 2020
- Mission IDs: MIS-0020
- Equipment status: OPERATIONAL
- Sources: 5; claims: 7; timeline events: 2

### MARS-EQ-0039 — InSight Seismic Experiment for Interior Structure (SEIS)
- Mission: InSight
- Mission IDs: Not assigned; no approved InSight mission ID available in supplied inventory
- Equipment status: null (not established)
- Sources: 6; claims: 9; timeline events: 6

### MARS-EQ-0040 — InSight Heat Flow and Physical Properties Package (HP³)
- Mission: InSight
- Mission IDs: Not assigned; no approved InSight mission ID available in supplied inventory
- Equipment status: null (not established)
- Sources: 7; claims: 10; timeline events: 7

## Global identifier audit scope

The earlier-archive maxima before Batch 8 are CLM-0568, EVT-0537, SRC-0152, DSC-0208, CON-0209, LOC-0103, MED-0110, INS-0117 and ATT-0020. Batch 8 allocations end at CLM-0606, EVT-0556, SRC-0167, DSC-0209 and CON-0210. No collisions were found within the archives actually inspected. The available Batch 2 corrected archive contains MARS-EQ-0006 through MARS-EQ-0008 only; MARS-EQ-0009 and MARS-EQ-0010 remain outside the audit scope.

## Report consistency correction (v1.2)

The technical verification and uncertainty reports were reconciled to the five equipment JSON records. Final statuses are SuperCam OPERATIONAL; MEDA OPERATIONAL (partial/degraded); RIMFAX OPERATIONAL; SEIS null; HP³ null. The three Perseverance instrument assessments are effective 2026-03-02 and are dated NASA senior-review assessments, not live telemetry. Per-equipment claim/source/timeline counts are checked against the JSON records.

## Verification limitations

All five records remain Draft and PARTIALLY_VERIFIED. Current rover/instrument conditions after the 2026-03-02 senior review are not represented as live telemetry. Unknown values and coordinates remain null. No unverified media were added.
