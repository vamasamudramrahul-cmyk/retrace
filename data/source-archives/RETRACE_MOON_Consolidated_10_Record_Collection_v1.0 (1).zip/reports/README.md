# RETRACE EQ-0005 status correction — redacted package

Contents: the corrected `MOON-EQ-0005.json`, the updated global source registry, validation report, change log, and SHA-256 manifest.

The package preserves the existing permanent IDs and the existing shared source reference `SRC-0008`. The SRC-0008 URL is the official NASA NTRS bibliographic record page, not a direct report-file URL. Operational subsystem details are intentionally excluded.

This targeted package does not include other equipment JSON records; those records are not modified by this correction.
