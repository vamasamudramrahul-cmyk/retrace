# RETRACE — MOON-EQ-0005 STATUS CLASSIFICATION CORRECTION (REDACTED DISTRIBUTION)

**Record:** `MOON-EQ-0005` — Apollo 14 Active Seismic Experiment  
**Correction date:** 2026-11-12  
**Disposition:** Targeted status correction; non-operational distribution

## Record changes

- Set `equipment_status` to `INACTIVE`.
- Added top-level `status_effective_date: 1975-03-05`; retained the nested status `effective_date` with the same value.
- Set `last_contact_date` to `null` and `physical_condition` to `UNKNOWN` (also retained in the nested status object).
- Kept `verification_status` as `PARTIALLY_VERIFIED`.
- Updated the current-status explanation and existing claim `CLM-0094` using NASA-RP-1036, Section 4, printed pp. 4-7 to 4-8.
- Reused the existing shared source ID `SRC-0008`; no duplicate source ID was created.
- Used the official NASA NTRS bibliographic record page as the source URL. The direct report-file locator is omitted from this redacted distribution. The same direct locator was also replaced in the registry's legacy `SRC-0016` entry because it points to the same report.
- Kept the January 1976 Apollo 14 station failure as the separate station-level event `EVT-0016` / `CLM-0030`.

## Evidence boundary

The status claim records only the non-operational status chronology needed to support the classification: loss of central-station command capability on 1975-03-05 and no change in ASE status at ALSEP termination on 1977-09-30. Operational subsystem details are not reproduced. The cited source does not establish a last-contact date or present physical condition.

## Registry and package scope

- Global registry source references: 43.
- Unique source identities: 30.
- `SRC-0008` remains intentionally shared; its `referenced_by_equipment_ids` list is preserved.
- This is a targeted EQ-0005 correction package. Other equipment JSON records are not included and have not been modified. The approved template and all other EQ-0005 research fields/IDs are retained.
- No Moon collection completion or independent audit approval is claimed.
