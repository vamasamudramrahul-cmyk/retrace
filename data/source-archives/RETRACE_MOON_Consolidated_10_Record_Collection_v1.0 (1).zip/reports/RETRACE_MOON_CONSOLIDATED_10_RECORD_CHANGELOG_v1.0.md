# Retrace Moon Consolidated Collection — Change Log v1.0

Date: 2026-11-12

## Package composition
- Consolidates the ten equipment records MOON-EQ-0001 through MOON-EQ-0010.
- Uses the latest available ten-record base (EQ-0010 Research v1.3), overlays the accepted EQ-0007 supplemental source correction, and overlays the accepted redacted EQ-0005 status correction.
- Includes separate registries: a global source registry and a mission registry.

## Targeted record overlays
- MOON-EQ-0005: `equipment_status=INACTIVE`; `status_effective_date=1975-03-05`; `last_contact_date=null`; `physical_condition=UNKNOWN`; `verification_status=PARTIALLY_VERIFIED`; existing source `SRC-0008` retained.
- MOON-EQ-0007: includes supplemental source `SRC-0030` supporting twelve thermometers per probe; no unsupported arrangement or performance details added.

## Registry distinction
- `RETRACE_MOON_GLOBAL_SOURCE_REGISTRY_v1.2_REDACTED.json` tracks source publications and their equipment citations.
- `RETRACE_MOON_MISSION_REGISTRY_v1.0.json` separately maps the five mission IDs present in the ten records to mission names and associated equipment IDs. It adds no unverified mission chronology or technical facts.

## Preservation
- Other equipment records are taken unchanged from the latest consolidated EQ-0010 v1.3 package, except EQ-0007 as updated by its supplemental correction and EQ-0005 as updated by its redacted status correction.
- Permanent equipment IDs and the approved master template are preserved.

## Audit boundary
This is a consolidated input package for the next audit, not an independent audit approval. No claim is made that all Moon equipment records are complete.
