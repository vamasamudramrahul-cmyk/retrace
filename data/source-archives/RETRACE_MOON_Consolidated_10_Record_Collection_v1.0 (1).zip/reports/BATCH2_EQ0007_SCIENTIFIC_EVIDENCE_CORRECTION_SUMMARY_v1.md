# RETRACE — Stage 5B EQ-0007 Targeted Scientific Correction v1

**Record:** MOON-EQ-0007 — Apollo 15 Heat Flow Experiment  
**Disposition:** Supplemental source correction completed; ready for independent audit.  
**Independent approval:** Not claimed.

## Corrections

1. **Mass:** `mass_kg` corrected from 4.6 kg to **9.9 kg total**. Added `ATT-0039` to preserve **4.6 kg electronics-box mass** separately, supported by NASA-RP-1317.
2. **Deployment depth:** Distinguished borestem penetration from probe insertion. Probe 1: 1.62 m borestem / approximately 1.40 m probe insertion. Probe 2: approximately 1.60 m borestem / probe insertion obstructed near 1.0 m. Added `ATT-0040` and `ATT-0041`; clarified existing `ATT-0026` and `ATT-0027`.
3. **Probe 2 data:** The upper section's bridge readings were invalid for much of the lunation cycle, but SP-289 reports useful lower-sensor subsurface temperature observations, including a temperature increase with depth comparable to Probe 1.
4. **Thermometer count:** Supplemental NASA-CR-151619 (NTRS 19780010035) explicitly states that each probe had twelve thermometers. The record now includes only that supported count; no arrangement, specifications or performance details are inferred.
5. **Sources:** Existing `SRC-0023` remains the NASA-RP-1317 source. Added `SRC-0030`, NASA-CR-151619, as the next globally unused source ID.

## Source page clarification

The handoff cited printed page 41 for the mass values. The NASA document's contents and HFE entry place the Heat Flow Experiment entry on **printed page 49**. The actual printed page reference is used in the record.

## Preserved information

- 9.0 W total power.
- Existing probe and electronics-box dimensions.
- Approximately 10 m (SP-289) and 8.5 m (NTRS) probe separation values.
- Preliminary 33 mW/m² and later 21 mW/m² results remain separate.
- Final OFF command on 1977-01-15.
- Existing permanent equipment ID, mission identity, unrelated claims and timeline events.

## Global validation

- All ten Moon equipment records parsed.
- All globally unique definition ID families checked: CLM, EVT, ATT, DSC, CON, INS, LOC and MED; no collisions remain.
- Shared SRC identifiers treated as references to shared source documents, not unique definitions. `SRC-0030` was unused before assignment; source references now total 42 across 30 unique source identities.
- All local claim/source/timeline/attribute/discovery/contribution references resolve.
- EQ-0006, EQ-0008, EQ-0009 and EQ-0010 unchanged byte-for-byte from the preceding Stage 5B package.
- Batch 1 v5 and approved template were not modified.
- ZIP integrity: checked in the accompanying supplemental validation report.

## Limitations

EQ-0007 remains `PARTIALLY_VERIFIED`. This targeted correction is not an independent scientific approval. The NTRS restoration source is cited at abstract level for its approximate values; no full-paper access is claimed.

## Supplemental source — SRC-0030

- NASA, *Lunar Heat-Flow Experiment*, NASA-CR-151619, Marcus G. Langseth, 1977-09-01.
- NASA NTRS document 19780010035: https://ntrs.nasa.gov/citations/19780010035
- Supported statement: each experiment probe had twelve thermometers. No other thermometer detail is inferred.

## Exact source references

- NASA-RP-1317, *Catalog of Apollo Experiment Operations*, HFE entry, printed p. 49: https://www.nasa.gov/wp-content/uploads/static/history/alsj/RP-1994-1317.pdf
- NASA SP-289, Section 11, printed pp. 11-3 to 11-8: https://www.nasa.gov/wp-content/uploads/static/history/alsj/a15/as15psr.pdf
- NASA-RP-1036: https://ntrs.nasa.gov/api/citations/19790014808/downloads/19790014808.pdf
- NASA NTRS restoration abstract: https://ntrs.nasa.gov/citations/20170002417

## File integrity

- Original EQ-0007 SHA-256: `0019e4299180177e5fc5b497e9bd3be32368386b62236238d8a1e2f8238626c4`
- Corrected EQ-0007 SHA-256: `3423ee576f83f3b0a4250041b9876c4ff7fe32f2a418292d4fea3597c679f5e4`
- Batch 1 v5 ZIP SHA-256: `6dee484711255345add4503aa6425d7602275fb5a7963762f1d0a51a03d33eb2`
- Approved template SHA-256: `67f91d7d6f6aeffafa309ad2be9c06ea40100ff9a66f53f8b0ba08f400d0bcb9`


## Supplemental source correction change log

- `CLM-0049.claim_text`: added the statement that each probe had twelve thermometers.
- `CLM-0049.source_ids`: added `SRC-0030`; retained the pre-existing supporting sources.
- `evidence.sources`: added `SRC-0030` with NASA NTRS bibliographic metadata.
- `primary_sources`: added `SRC-0030`.
- `verification_status`: unchanged (`PARTIALLY_VERIFIED`).

## Updated collection source counts

- Source references: **42**.
- Unique source identities: **30**.
- New source ID: `SRC-0030`.
- Prior highest assigned source ID: `SRC-0029`.
- EQ-0007 remains `PARTIALLY_VERIFIED`; the Moon collection is not declared complete.

- Global source registry SHA-256: `554f757051f138b354aab0dd0f538fe44d9c7267af5470cb1a9c3fbff1e68e76`
