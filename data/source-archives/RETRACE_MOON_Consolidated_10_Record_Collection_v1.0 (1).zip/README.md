# RETRACE Moon Consolidated Collection — 10 Records

Contains ten permanent Moon equipment records (MOON-EQ-0001–MOON-EQ-0010), the approved full-details template, a global source registry, a separate mission registry, and supporting correction/audit reports.

Important: the source registry and mission registry serve different purposes. The source registry tracks publications and citations. The mission registry maps mission IDs to mission names and associated equipment IDs.

This package is prepared as an input to the next independent audit. It is not itself an audit approval and does not declare the Moon collection complete.
